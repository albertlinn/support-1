
<!DOCTYPE html>
<html>
	<head>
		<title>upload</title>
	</head>
	<body>

<form class="form-horizontal" method="post" action="/user/icon-upload" accept-charset="UTF-8" enctype="multipart/form-data">  
    <input type="file" class="form-control" id="user_icon_file" name="user_icon_file" placeholder="上傳圖片" value="">
</form> 
	</body>
</html>
