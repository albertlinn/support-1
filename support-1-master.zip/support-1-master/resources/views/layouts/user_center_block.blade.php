<div class="panel panel-default">
	<div class="panel-heading" style="height:100%;">
		<div class="row-menu" style="height:40px;">
			<ul class="drop-down-menu1">
			    <li style="border-color:#D3E0E9;"><a href="/group">Group</a>
			    </li>
			    <li><a href="/role">Role</a>
			    </li>
			    <li>
			    @role('devenlope')
			    <a href="/permission">Permission</a>
			    @endrole
			    </li>
			</ul>
		</div>
	</div>
</div>

