<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
    	<h2>Hi,{{$license->name}}</h2>
        <font size="4" style="color:#FF6600;">{{$license->company_name}}</font>
        <font size="4"> License授權時間將於
        <font size="4" style="color:#0000CC;">{{$license->expir_at}}</font>
        到期，
        </font>
        <P>如需申請展延，敬請提早洽談續約事宜並預留申請作業時間。</P>
        <P>預祝您一切順利！</P>
        <P>
            此為系統自動發送，請勿回覆。您若要聯絡我們，請傳送到 support@teamplus.com.tw 我們便會回覆您。
        </P>
    </body>
</html>