<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
    	<h2>Hi,{{$Mailtest->name}}</h2>
    	<P>客服系統測試MAIL通知~</P>
        <P>
            此為系統自動發送，請勿回覆。您若要聯絡我們，請傳送到 support@teamplus.com.tw 我們便會回覆您。
        </P>
    </body>
</html>