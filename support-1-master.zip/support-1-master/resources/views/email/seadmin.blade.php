<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
    	<h2>Hi</h2>
    	<h2>您好我是客服小叮噹</h2>
    	<h2>請{{$seadmin->name}}馬上關閉{{$seadmin->company_name}}的TLC功能唷~</h2>
        <h2>https://cloud.teamplus.com.tw/PrivateCloudManage/view/Login.aspx?q=relogin</h2>
    	<h2>Thanks</h2>
        <h2></h2>
        
    </body>
</html>