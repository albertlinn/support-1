<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
    	<h2>您好,我是客服小叮噹</h2>
    	<h4>您負責的 <h3 style="color:#FF0000;">{{$company}}</h3> SyncDaemon 版本過舊!</h4>
    	<h4> 請注意唷 噹噹噹<h3 style="color:#FF0000;"></h3></h4>
    	<h4>FYI~</h4>
    </body>
</html>