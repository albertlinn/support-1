<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
    	<h4>您好,我是</h4><h2>客服小叮噹</h2>
    	<h4>附件為客戶版號自動撈取結果</h4>
    	<h4>FYI~</h4>
    </body>
</html>