@extends('layouts.master')

@section('title')
<h2 style="margin-top: 2px">合約與發票</h2>
@endsection

@section('contentm')
<!--中間選單-->
<div class="container" style="width:780px;height:75px;margin-right:218px;">
	@include('layouts.center_block')
</div>						
@endsection
