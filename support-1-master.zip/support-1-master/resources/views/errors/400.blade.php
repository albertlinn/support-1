<div style="margin:0 auto;width:1700px"><img src="/storage/400.png" style="display:block;margin:0 auto;"></div>

<script type="text/javascript">
    window.setTimeout(function() {
        window.location.herf=history.back();
    }, 1000);
</script>